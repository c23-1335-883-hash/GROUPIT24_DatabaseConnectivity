const questions = [
  { question: "Which planet is known as the Red Planet?", answers: ["Venus", "Mars", "Jupiter", "Mercury"], correct: 1 },
  { question: "How many days are there in a leap year?", answers: ["364", "365", "366", "367"], correct: 2 },
  { question: "Which animal is known as man's best friend?", answers: ["Cat", "Dog", "Rabbit", "Horse"], correct: 1 },
  { question: "What is 8 × 7?", answers: ["54", "56", "64", "48"], correct: 1 },
  { question: "Which ocean is the largest?", answers: ["Atlantic", "Indian", "Arctic", "Pacific"], correct: 3 },
  { question: "What do plants absorb from the air?", answers: ["Oxygen", "Carbon dioxide", "Helium", "Hydrogen"], correct: 1 },
  { question: "Which language is mainly used to style web pages?", answers: ["HTML", "CSS", "SQL", "Python"], correct: 1 },
  { question: "How many sides does a triangle have?", answers: ["Two", "Three", "Four", "Five"], correct: 1 },
  { question: "What is the capital city of Japan?", answers: ["Seoul", "Beijing", "Tokyo", "Bangkok"], correct: 2 },
  { question: "Which device is used to move the pointer on a computer?", answers: ["Printer", "Speaker", "Mouse", "Scanner"], correct: 2 }
];

const STORAGE_KEY = "quizMasterSavedScores";
let playerName = "";
let questionIndex = 0;
let score = 0;
let selectedAnswer = null;
let resultSaved = false;

const startScreen = document.getElementById("start-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const playerInput = document.getElementById("player-name");
const questionCount = document.getElementById("question-count");
const currentScore = document.getElementById("current-score");
const questionText = document.getElementById("question-text");
const answersBox = document.getElementById("answers");
const answerMessage = document.getElementById("answer-message");
const nextButton = document.getElementById("next-btn");
const resultText = document.getElementById("result-text");
const saveMessage = document.getElementById("save-message");
const scoresTable = document.getElementById("scores-table");

document.getElementById("start-btn").addEventListener("click", startGame);
nextButton.addEventListener("click", nextQuestion);
document.getElementById("save-btn").addEventListener("click", saveResult);
document.getElementById("play-again-btn").addEventListener("click", resetGame);
document.getElementById("clear-btn").addEventListener("click", clearScores);

function startGame() {
  const name = playerInput.value.trim();
  if (!name) {
    document.getElementById("start-message").textContent = "Please enter your name first.";
    return;
  }
  playerName = name;
  questionIndex = 0;
  score = 0;
  resultSaved = false;
  startScreen.classList.add("hidden");
  resultScreen.classList.add("hidden");
  quizScreen.classList.remove("hidden");
  showQuestion();
}

function showQuestion() {
  selectedAnswer = null;
  nextButton.disabled = true;
  answerMessage.textContent = "";
  currentScore.textContent = score;
  questionCount.textContent = `Question ${questionIndex + 1} of ${questions.length}`;
  questionText.textContent = questions[questionIndex].question;
  answersBox.innerHTML = "";

  questions[questionIndex].answers.forEach((answer, index) => {
    const button = document.createElement("button");
    button.className = "answer-btn";
    button.textContent = `${String.fromCharCode(65 + index)}. ${answer}`;
    button.addEventListener("click", () => chooseAnswer(index, button));
    answersBox.appendChild(button);
  });
}

function chooseAnswer(index, clickedButton) {
  if (selectedAnswer !== null) return;
  selectedAnswer = index;
  const question = questions[questionIndex];
  const buttons = answersBox.querySelectorAll("button");
  buttons.forEach((button, i) => {
    button.disabled = true;
    if (i === question.correct) button.classList.add("correct");
  });

  if (index === question.correct) {
    score += 1;
    answerMessage.textContent = "Correct! You earned 1 point.";
  } else {
    clickedButton.classList.add("wrong");
    answerMessage.textContent = `Not quite. The correct answer is ${question.answers[question.correct]}.`;
  }
  currentScore.textContent = score;
  nextButton.disabled = false;
  nextButton.textContent = questionIndex === questions.length - 1 ? "Show Result" : "Next Question";
}

function nextQuestion() {
  if (selectedAnswer === null) return;
  questionIndex += 1;
  if (questionIndex >= questions.length) {
    showResult();
  } else {
    nextButton.textContent = "Next Question";
    showQuestion();
  }
}

function showResult() {
  quizScreen.classList.add("hidden");
  resultScreen.classList.remove("hidden");
  const percent = Math.round((score / questions.length) * 100);
  resultText.textContent = `${playerName}, you scored ${score} out of ${questions.length} (${percent}%).`;
  document.getElementById("save-btn").disabled = false;
  saveMessage.textContent = "";
}

function getSavedScores() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (error) {
    return [];
  }
}

function saveResult() {
  if (resultSaved) {
    saveMessage.textContent = "This result has already been saved.";
    return;
  }
  const savedScores = getSavedScores();
  const newRecord = {
    player_id: Date.now(),
    player_name: playerName,
    score: score,
    total_questions: questions.length,
    percentage: Math.round((score / questions.length) * 100),
    created_at: new Date().toLocaleString()
  };
  savedScores.unshift(newRecord);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(savedScores));
  resultSaved = true;
  document.getElementById("save-btn").disabled = true;
  saveMessage.textContent = "Result saved successfully in this browser.";
  displayScores();
}

function displayScores() {
  const savedScores = getSavedScores();
  scoresTable.innerHTML = "";
  if (savedScores.length === 0) {
    scoresTable.innerHTML = '<tr><td colspan="4">No saved scores yet.</td></tr>';
    return;
  }
  savedScores.forEach(record => {
    const row = document.createElement("tr");
    [record.player_name, `${record.score}/${record.total_questions}`, `${record.percentage}%`, record.created_at]
      .forEach(value => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
    scoresTable.appendChild(row);
  });
}

function clearScores() {
  if (confirm("Delete all saved scores from this browser?")) {
    localStorage.removeItem(STORAGE_KEY);
    displayScores();
  }
}

function resetGame() {
  resultScreen.classList.add("hidden");
  startScreen.classList.remove("hidden");
  playerInput.value = "";
  document.getElementById("start-message").textContent = "";
  resultSaved = false;
}

displayScores();
