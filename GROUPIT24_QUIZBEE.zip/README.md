# Quiz Master — Student Project

A simple browser-based multiple-choice quiz game made with HTML, CSS, and JavaScript.

## How to run
1. Extract the ZIP file.
2. Open `index.html` in Google Chrome, Microsoft Edge, or Firefox.
3. Enter a player name and press **Start Game**.
4. Answer the 10 questions.
5. Press **Save Result** after the quiz to save the result.
6. Refresh the page and confirm that saved scores are still displayed.

## Data storage
This project uses browser `localStorage`, with the key `quizMasterSavedScores`. The data is stored as JSON in the browser profile on the current device. It is not a shared online database and does not sync to other devices.

Each saved record contains:
- `player_id`: generated identifier based on the save time
- `player_name`: name entered by the player
- `score`: number of correct answers
- `total_questions`: number of questions in the quiz
- `percentage`: score percentage
- `created_at`: local date and time when the result was saved

## Main functions
- Start quiz with a player name
- Show multiple-choice questions
- Check answers and calculate the score
- Display the final score and percentage
- Save and retrieve quiz records
- Display saved results in a table
- Clear saved results after confirmation

## Important
Use your own screenshots of the running game in the report. Test the project yourself and update the report to reflect your actual results. For a shared online database, the project would need a backend or database service.
